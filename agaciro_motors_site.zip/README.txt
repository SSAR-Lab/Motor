Agaciro Motors - Static multi-page HTML demo
-------------------------------------------
Files:
- index.html, vehicles.html, reservation.html, report.html, contact.html
- assets/ (style.css, logo.png)
- scripts/ (main.js, vehicles.js, reservation.js, report.js, pdf.js)

Usage:
- Open index.html in a browser for demo.
- The app stores vehicles & reservations in localStorage.
- Admin operations (add/edit/delete vehicles) require password: admin123

To deploy to Vercel:
- Create a new GitHub repo, push these files.
- Import to Vercel (Static Site) and deploy.
