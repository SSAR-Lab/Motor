
// vehicles.js - admin add/edit/delete vehicles, stored in localStorage
const ADMIN_PASS = "admin123"; // change if needed

function ensureAdmin(){
  if(sessionStorage.getItem('adminAuth') === '1') return true;
  const p = prompt('Enter admin password:');
  if(p === ADMIN_PASS){ sessionStorage.setItem('adminAuth','1'); return true; }
  alert('Wrong password');
  return false;
}

function getVehicles(){
  return JSON.parse(localStorage.getItem('agaciro_vehicles') || '[]');
}
function saveVehicles(v){ localStorage.setItem('agaciro_vehicles', JSON.stringify(v)); }

function renderVehicleList(){
  const list = getVehicles();
  const container = document.getElementById('vehicleList');
  if(!container) return;
  container.innerHTML = '';
  list.forEach((v)=>{
    const div = document.createElement('div');
    div.className = 'vehicle-card';
    div.innerHTML = `<div class="vehicle-title">${v.brand} ${v.name}</div>
      <div class="vehicle-plate">${v.plate}</div>
      <div class="vehicle-rate">${v.rate} RWF / day</div>
      <div class="vehicle-status">${isReserved(v) ? '<span class="badge res">Reserved</span>' : '<span class="badge free">Free</span>'}</div>
      <div style="margin-top:8px">
        <button class="btn small" onclick="startEdit('${v.id}')">Edit</button>
        <button class="btn small alt" onclick="deleteVehicle('${v.id}')">Delete</button>
      </div>`;
    container.appendChild(div);
  });
}

function isReserved(v){
  const reservations = JSON.parse(localStorage.getItem('agaciro_reservations')||'[]');
  const today = new Date();
  return reservations.some(r=>{
    if(r.carId !== v.id) return false;
    const from = new Date(r.from); const to = new Date(r.to);
    return today >= from && today <= to;
  });
}

function addVehicleFromForm(e){
  e.preventDefault();
  if(!ensureAdmin()) return;
  const brand = document.getElementById('v_brand').value.trim();
  const name = document.getElementById('v_name').value.trim();
  const plate = document.getElementById('v_plate').value.trim();
  const rate = document.getElementById('v_rate').value.trim();
  if(!brand||!name||!plate) return alert('Fill all fields');
  const v = { id: 'v_'+Math.random().toString(36).slice(2,9), brand, name, plate, rate };
  const arr = getVehicles(); arr.push(v); saveVehicles(arr); renderVehicleList();
  document.getElementById('addVehicleForm').reset();
}

function startEdit(id){
  if(!ensureAdmin()) return;
  const arr = getVehicles(); const v = arr.find(x=>x.id===id);
  if(!v) return;
  document.getElementById('v_brand').value = v.brand;
  document.getElementById('v_name').value = v.name;
  document.getElementById('v_plate').value = v.plate;
  document.getElementById('v_rate').value = v.rate;
  document.getElementById('addVehicleBtn').innerText = 'Save';
  document.getElementById('addVehicleForm').onsubmit = function(e){
    e.preventDefault();
    v.brand = document.getElementById('v_brand').value.trim();
    v.name = document.getElementById('v_name').value.trim();
    v.plate = document.getElementById('v_plate').value.trim();
    v.rate = document.getElementById('v_rate').value.trim();
    saveVehicles(arr); renderVehicleList();
    document.getElementById('addVehicleForm').reset();
    document.getElementById('addVehicleBtn').innerText = 'Add';
    document.getElementById('addVehicleForm').onsubmit = addVehicleFromForm;
  };
}

function deleteVehicle(id){
  if(!ensureAdmin()) return;
  if(!confirm('Delete vehicle?')) return;
  const arr = getVehicles().filter(x=>x.id!==id);
  saveVehicles(arr); renderVehicleList();
}

document.addEventListener('DOMContentLoaded', ()=>{
  if(document.getElementById('addVehicleForm')) document.getElementById('addVehicleForm').onsubmit = addVehicleFromForm;
  renderVehicleList();
});
