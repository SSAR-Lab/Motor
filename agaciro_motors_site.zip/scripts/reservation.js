
// reservation.js - manage reservations stored in localStorage and generate PDF receipts (uses jsPDF and QRCode via CDN)
function getReservations(){ return JSON.parse(localStorage.getItem('agaciro_reservations')||'[]'); }
function saveReservations(r){ localStorage.setItem('agaciro_reservations', JSON.stringify(r)); }

function submitReservation(e){
  e.preventDefault();
  const name = document.getElementById('res_name').value.trim();
  const email = document.getElementById('res_email').value.trim();
  const phone = document.getElementById('res_phone').value.trim();
  const carId = document.getElementById('res_car').value;
  const from = document.getElementById('res_from').value;
  const to = document.getElementById('res_to').value;
  const expectedKm = document.getElementById('res_expectedKm').value || '';
  const currency = document.getElementById('res_currency').value || 'RWF';
  const deposit = Number(document.getElementById('res_deposit').value || 0);
  if(!name||!carId||!from||!to) return alert('Fill all required fields');
  // check availability
  const cars = JSON.parse(localStorage.getItem('agaciro_vehicles')||'[]');
  const car = cars.find(c=>c.id===carId);
  const reservations = getReservations();
  const overlap = reservations.some(r=> r.carId===carId && !(new Date(to) < new Date(r.from) || new Date(from) > new Date(r.to)));
  if(overlap) return alert('Car not available for selected dates');
  const res = { id:'r_'+Math.random().toString(36).slice(2,9), carId, customerName:name, email, phone, from, to, expectedKm, payments:[ { id:'p_'+Date.now(), amount:deposit, currency, type:'deposit', date:new Date().toISOString()} ] };
  reservations.push(res); saveReservations(reservations);
  alert('Reservation created. Receipt will download.');
  // generate receipt
  setTimeout(()=> generateReceipt(res, car), 200);
  document.getElementById('reservationForm').reset();
}

async function generateReceipt(reservation, car){
  try{
    const doc = new jspdf.jsPDF(); // jspdf is from CDN, jspdf property may be jspdf or jsPDF based on include
    // try both
    if(window.jspdf && window.jspdf.jsPDF) doc = new window.jspdf.jsPDF();
  }catch(e){ /* ignore */ }
  // We will attempt to use jsPDF global (var jsPDF or jspdf)
  const PDF = (window.jspdf && window.jspdf.jsPDF) ? window.jspdf.jsPDF : (window.jsPDF ? window.jsPDF : null);
  if(!PDF){ alert('PDF generator not loaded'); return; }
  const doc = new PDF({ unit:'pt', format:'a4' });
  // logo
  try{
    const resp = await fetch('/assets/logo.png'); const blob = await resp.blob(); const url = URL.createObjectURL(blob);
    doc.addImage(url, 'PNG', 40, 30, 80, 40);
  }catch(e){}
  doc.setFontSize(16); doc.text('Agaciro Motors', 140, 55);
  doc.setFontSize(12); doc.text('Where Value Drives You.', 140, 75);
  doc.setFontSize(12); doc.text(`Receipt: ${reservation.id}`, 40, 110);
  doc.text(`Customer: ${reservation.customerName}`, 40, 130);
  if(car) doc.text(`Vehicle: ${car.brand} ${car.name} (${car.plate})`, 40, 150);
  doc.text(`Period: ${reservation.from} → ${reservation.to}`, 40, 170);
  doc.text(`Amount paid: ${reservation.payments.map(p=>p.amount+' '+p.currency).join(', ')}`, 40, 190);
  // QR
  try{
    const qr = await QRCode.toDataURL('booking:'+reservation.id);
    doc.addImage(qr, 'PNG', 420, 40, 120, 120);
  }catch(e){}
  doc.save(`Agaciro_Receipt_${reservation.id}.pdf`);
}

document.addEventListener('DOMContentLoaded', ()=>{
  const form = document.getElementById('reservationForm');
  if(form) form.onsubmit = submitReservation;
  // populate car select
  const sel = document.getElementById('res_car');
  if(sel){
    const cars = JSON.parse(localStorage.getItem('agaciro_vehicles')||'[]');
    sel.innerHTML = '<option value="">-- choose a vehicle --</option>';
    cars.forEach(c=> sel.innerHTML += `<option value="${c.id}">${c.brand} ${c.name} (${c.plate})</option>`);
  }
});
