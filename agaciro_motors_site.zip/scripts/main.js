
// main.js - language handling and small helpers
const dict = {
  en: {
    home: "Home", vehicles: "Vehicles", reservations: "Reservations", contact: "Contact",
    addVehicle: "Add Vehicle", reserve: "Reserve", available: "Available", reserved: "Reserved",
    from: "From", to: "To", expectedKm: "Expected Km", customer: "Customer", makeReservation: "Make Reservation",
    contactUs: "Contact Us"
  },
  ki: {
    home: "Uru rupapuro rw'umutwe", vehicles: "Imodoka", reservations: "Ibyaguzwe", contact: "Twandikire",
    addVehicle: "Ongeramo Imodoka", reserve: "Bika", available: "Irahari", reserved: "Yafashwe",
    from: "Kuva", to: "Kugeza", expectedKm: "Km zitezwe", customer: "Umukiriya", makeReservation: "Kora Itegeko",
    contactUs: "Twandikire"
  },
  cn: {
    home: "主页", vehicles: "车辆", reservations: "预订", contact: "联系我们",
    addVehicle: "添加车辆", reserve: "预订", available: "可用", reserved: "已预订",
    from: "从", to: "到", expectedKm: "预计公里数", customer: "客户", makeReservation: "创建预订",
    contactUs: "联系我们"
  }
};

function setLang(lang){
  localStorage.setItem('siteLang', lang);
  applyLang(lang);
}

function applyLang(lang){
  const d = dict[lang] || dict.en;
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    if(d[key]) el.innerText = d[key];
  });
  // set selects where needed
  const selects = document.querySelectorAll('select[data-i18n]');
  selects.forEach(s=>{
    const key = s.getAttribute('data-i18n');
    if(key && dict[lang][key]) s.options[0].text = dict[lang][key];
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  const lang = localStorage.getItem('siteLang') || 'en';
  const sel = document.getElementById('langSelect');
  if(sel){ sel.value = lang; sel.addEventListener('change', ()=> setLang(sel.value)); }
  applyLang(lang);
});
