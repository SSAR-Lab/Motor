
// report.js - record departure and return odometer and compute distance
function getReservations(){ return JSON.parse(localStorage.getItem('agaciro_reservations')||'[]'); }
function saveReservations(r){ localStorage.setItem('agaciro_reservations', JSON.stringify(r)); }

function populateReportList(){
  const sel = document.getElementById('rep_select');
  if(!sel) return;
  sel.innerHTML = '<option value="">-- choose reservation --</option>';
  getReservations().forEach(r=>{
    const carList = JSON.parse(localStorage.getItem('agaciro_vehicles')||'[]');
    const car = carList.find(c=>c.id===r.carId);
    sel.innerHTML += `<option value="${r.id}">${car? (car.brand+' '+car.name): r.carId} — ${r.customerName} (${r.from} → ${r.to})</option>`;
  });
}

function saveMileage(e){
  e.preventDefault();
  const resId = document.getElementById('rep_select').value;
  const start = Number(document.getElementById('rep_start').value || 0);
  const end = Number(document.getElementById('rep_end').value || 0);
  if(!resId) return alert('Select reservation');
  const arr = getReservations();
  const r = arr.find(x=>x.id===resId);
  if(!r) return alert('Reservation not found');
  r.mileageStart = start; r.mileageEnd = end;
  saveReservations(arr);
  alert('Mileage saved. Distance: '+(end-start)+' km');
  document.getElementById('reportForm').reset();
}

document.addEventListener('DOMContentLoaded', ()=>{ populateReportList(); });
